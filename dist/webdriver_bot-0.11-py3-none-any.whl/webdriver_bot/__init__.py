from .bot import SeleniumBot

assert SeleniumBot
